﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CarService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class CarService : ICarService
    {
                
        Double CarAmount = 2000.00;

        public string BidForCar(double Amount)
        {
            Double AmountLeft;
            StringBuilder builder = new StringBuilder();
            try
            {
                if (CarAmount != 0)
                {
                    AmountLeft = CarAmount = -Convert.ToDouble(Amount);
                    builder.AppendLine(String.Format("Amount Left to pay is {0}", AmountLeft));
                }
                else if (CarAmount == 0)
                {
                    builder.AppendLine("Drive the car away you have paid all");
                }

                else
                {
                    builder.AppendLine("We cannot process your payment");
                }
                return builder.ToString();
            }

            catch (Exception e)
            {
                return e.Message;
            }
        }
      
    }
}

















    //}
    //}
 
